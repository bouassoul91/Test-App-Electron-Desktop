import React, { useEffect, useMemo, useRef, useState } from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";

function onGridReady(params) {
  console.log("✅ Grid READY", params.api);
  setGridApi(params.api);
}

function Chip({ text }) {
  return <span className="chip">{text}</span>;
}

function ServicesCell({ value }) {
  const arr = Array.isArray(value) ? value : [];
  return (
    <div className="chipRow">
      {arr.map((s) => (
        <Chip key={s} text={s} />
      ))}
    </div>
  );
}

function NotifyButtonCell(props) {
  const { data } = props;
  const disabled = !!data?.notified;

  return (
    <button
      className="btn"
      disabled={disabled}
      onClick={async () => {
        await window.api.leads.notifySales(data.id);
        props.api.applyTransaction({ update: [{ ...data, notified: true }] });
      }}
    >
      {disabled ? "Notified" : "Notify Sales team"}
    </button>
  );
}

export default function App() {
  const gridRef = useRef(null);
  const [gridApi, setGridApi] = useState(null);
  const [rowData, setRowData] = useState([]);
  const [quickFilter, setQuickFilter] = useState("");

  console.log("Test Console App");
  console.log("Test Console rowData");
  console.log(rowData);

  console.log("window.api =", window.api);

  useEffect(() => {
    (async () => {
      try {
        console.log("Calling API...");

        const leads = await window.api?.test(); //await window.api.leads.listLeads();

        console.log("Returned:");
        console.log(leads);

        setRowData(leads);

      } catch (err) {
        console.error("API Error:", err);
      }
    })();
  }, []);

  console.log("Test Console rowData");
  console.log(rowData);

  const colDefs = useMemo(
    () => [
      { headerName: "ID", field: "id", width: 130, pinned: "left" },
      { headerName: "Email", field: "email", flex: 1, editable: true },
      { headerName: "Company name", field: "company_name", flex: 1, editable: true },
      {
        headerName: "Notify sales team",
        field: "notified",
        width: 180,
        cellRenderer: NotifyButtonCell,
        sortable: false,
        filter: false,
      },
      {
        headerName: "Which services are you ...",
        field: "services",
        flex: 1,
        editable: true,
        cellRenderer: ServicesCell,
        valueParser: (p) => {
          // allow editing as comma-separated text: "SEO, Press"
          if (Array.isArray(p.newValue)) return p.newValue;
          const s = String(p.newValue ?? "")
            .split(",")
            .map((x) => x.trim())
            .filter(Boolean);
          return s;
        },
      },
      { headerName: "Phone number", field: "phone", width: 180, editable: true },
    ],
    []
  );

  const defaultColDef = useMemo(
    () => ({
      resizable: true,
      sortable: true,
      filter: true,
    }),
    []
  );

  async function onCellValueChanged(e) {
    const { id } = e.data;
    const patch = { [e.colDef.field]: e.data[e.colDef.field] };
    await window.api.leads.updateLead(id, patch);
  }

  async function addRow() {
    console.log("Create button clicked");
    if (!gridApi) {
      console.warn("Grid not ready yet");
      return;
    }

    const newLead = {
      email: "",
      company_name: "",
      phone: "",
      services: [],
      notified: false,
    };

    const res = await window.api.leads.createLead(newLead);
    const full = { id: res.id, ...newLead };

    gridApi.applyTransaction({ add: [full], addIndex: 0 });
    //gridRef.current.api.applyTransaction({ add: [full], addIndex: 0 });
  }

  async function deleteSelected() {
    const api = gridRef.current.api;
    const selected = api.getSelectedRows();
    for (const r of selected) await window.api.leads.deleteLead(r.id);
    api.applyTransaction({ remove: selected });
  }

  return (
    <div className="shell">
      <header className="topbar">
        <div className="title">Lead Capture: Leads</div>
        <div className="spacer" />
        <input
          className="search"
          placeholder="Search records"
          value={quickFilter}
          onChange={(e) => {
            const v = e.target.value;
            setQuickFilter(v);
            gridRef.current.api.setGridOption("quickFilterText", v);
          }}
        />
        <button className="btnPrimary" onClick={addRow}>+ Create</button>
        <button className="btnDanger" onClick={deleteSelected}>Delete</button>
      </header>

      <div className="gridWrap">
        <div className="ag-theme-alpine gridContainer">
          <AgGridReact
            onGridReady={onGridReady}
            rowData={rowData}
            columnDefs={colDefs}
            defaultColDef={defaultColDef}
            rowSelection="multiple"
            animateRows
            getRowId={(p) => p.data.id}
            onCellValueChanged={onCellValueChanged}
          />
        </div>
      </div>
    </div>
  );
}
